var tempF = Number(prompt("Digite a temperatura em ºF para converter para ºC: "));

tempC = (tempF - 32)*5/9

//alert(tempF+"ºF" + " em ºC é: " + tempC +"ºC");

alert(tempF+"ºF" + " em ºC é: " + (tempF - 32)*5/9 +"ºC");