var numero = Number(prompt("Digite um número para descobrir o seu cubo: "));

alert("O cubo de " + numero + " é: " + numero**3);