var firstName = window.prompt("Digite seu primeiro nome:");
var secondName = window.prompt("Digite seu sobrenome:");

alert("Seu nome completo é: " + firstName + " " + secondName);